public class Ejercicio10
{
    
}
